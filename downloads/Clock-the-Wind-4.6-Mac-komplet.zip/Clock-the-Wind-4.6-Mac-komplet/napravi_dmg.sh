#!/bin/bash
# Clock the Wind 4.6 – izrada DMG-a na ovom Macu (Apple-ovi alati: codesign, hdiutil).
# Pokretanje u Terminalu:  bash napravi_dmg.sh
set -euo pipefail
cd "$(dirname "$0")"
APP="Clock the Wind.app"
VER=4.6
echo "1/6 Provjera sadržaja (SHA-256, identično DMG-u s GitHuba)…"
shasum -a 256 -c MANIFEST.sha256 --quiet
echo "    sve datoteke odgovaraju ($(wc -l < MANIFEST.sha256 | tr -d ' ') datoteka)"
echo "2/6 Uklanjanje oznake 'preuzeto s interneta' (karantena)…"
xattr -cr "$APP"
chmod 755 "$APP/Contents/MacOS/ClockTheWind"
echo "3/6 Lokalni potpis (ad-hoc)…"
codesign --force --deep --sign - "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"
echo "4/6 Izrada DMG-a…"
rm -rf stage "Clock-the-Wind-$VER.dmg"
mkdir stage && cp -R "$APP" stage/ && ln -s /Applications stage/Applications
hdiutil create -volname "Clock the Wind" -srcfolder stage -ov -format UDZO "Clock-the-Wind-$VER.dmg" >/dev/null
rm -rf stage
echo "5/6 Provjera DMG-a…"
hdiutil verify "Clock-the-Wind-$VER.dmg" >/dev/null
MNT=$(hdiutil attach -nobrowse -readonly "Clock-the-Wind-$VER.dmg" | grep -o '/Volumes/.*' | head -1)
codesign --verify --deep --strict "$MNT/$APP"
V=$(/usr/libexec/PlistBuddy -c "Print :CFBundleShortVersionString" "$MNT/$APP/Contents/Info.plist")
grep -q "Verzija $VER" "$MNT/$APP/Contents/Resources/web/js/app.js"
hdiutil detach "$MNT" >/dev/null
xattr -c "Clock-the-Wind-$VER.dmg" 2>/dev/null || true
echo "6/6 Gotovo: $(pwd)/Clock-the-Wind-$VER.dmg (verzija $V)"
echo "    SHA-256: $(shasum -a 256 "Clock-the-Wind-$VER.dmg" | cut -d' ' -f1)"
open -R "Clock-the-Wind-$VER.dmg" 2>/dev/null || true
